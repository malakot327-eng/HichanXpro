import re

_DIGIT_MAP = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")

def normalize_phone(value):
    if value is None:
        return None
    s=str(value).strip().translate(_DIGIT_MAP)
    s=s.replace(" ","").replace("-","").replace("(","").replace(")","")
    if s.startswith("00"):
        s="+"+s[2:]
    elif s.startswith("09"):
        s="+98"+s[1:]
    elif s.startswith("98"):
        s="+"+s
    if not re.fullmatch(r"\+98\d{10}",s):
        return None
    if s[3] not in "9":
        return None
    return s

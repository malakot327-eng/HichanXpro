import json, sqlite3, time
from pathlib import Path

class Database:
    def __init__(self, path='data/hichanx.db'):
        self.path = path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self._init()
    def _init(self):
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS groups(chat_id TEXT PRIMARY KEY,title TEXT,installed_by TEXT,created_at REAL,enabled INTEGER DEFAULT 1,plan TEXT DEFAULT 'normal',subscription_until REAL DEFAULT 0,subscription_type TEXT DEFAULT 'normal',settings_json TEXT DEFAULT '{}');
        CREATE TABLE IF NOT EXISTS install_requests(id INTEGER PRIMARY KEY AUTOINCREMENT,chat_id TEXT NOT NULL,title TEXT,requester_splus_id TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',created_at REAL,reviewed_at REAL,reviewer TEXT);
        CREATE TABLE IF NOT EXISTS group_admins(chat_id TEXT NOT NULL,splus_user_id TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'admin',telegram_user_id INTEGER,created_at REAL,PRIMARY KEY(chat_id,splus_user_id));
        CREATE TABLE IF NOT EXISTS telegram_group_links(telegram_user_id INTEGER NOT NULL,chat_id TEXT NOT NULL,splus_user_id TEXT,created_at REAL,PRIMARY KEY(telegram_user_id,chat_id));
        CREATE TABLE IF NOT EXISTS mutes(chat_id TEXT NOT NULL,user_id TEXT NOT NULL,until_ts REAL,PRIMARY KEY(chat_id,user_id));
        CREATE TABLE IF NOT EXISTS mute_migrations(chat_id TEXT PRIMARY KEY,migrated_at REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS points(chat_id TEXT NOT NULL,user_id TEXT NOT NULL,points INTEGER DEFAULT 0,PRIMARY KEY(chat_id,user_id));
        CREATE TABLE IF NOT EXISTS audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT,actor TEXT,scope TEXT,action TEXT,target TEXT,details TEXT,created_at REAL);
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT);
        CREATE TABLE IF NOT EXISTS accounts(phone TEXT PRIMARY KEY,session_path TEXT NOT NULL,active INTEGER DEFAULT 1,last_login REAL,created_at REAL);
        CREATE TABLE IF NOT EXISTS filters(chat_id TEXT NOT NULL,word TEXT NOT NULL,PRIMARY KEY(chat_id,word));
        CREATE TABLE IF NOT EXISTS moderation_state(
            chat_id TEXT NOT NULL,user_id TEXT NOT NULL,strikes INTEGER NOT NULL DEFAULT 0,
            updated_at REAL NOT NULL,PRIMARY KEY(chat_id,user_id));
        CREATE TABLE IF NOT EXISTS moderation_categories(
            chat_id TEXT NOT NULL,user_id TEXT NOT NULL,category TEXT NOT NULL,
            count INTEGER NOT NULL DEFAULT 0,updated_at REAL NOT NULL,
            PRIMARY KEY(chat_id,user_id,category));
        CREATE TABLE IF NOT EXISTS moderation_events(
            id INTEGER PRIMARY KEY AUTOINCREMENT,chat_id TEXT NOT NULL,user_id TEXT NOT NULL,
            message_id TEXT,category TEXT NOT NULL,reason TEXT NOT NULL,created_at REAL NOT NULL);
        CREATE UNIQUE INDEX IF NOT EXISTS idx_moderation_event_message
            ON moderation_events(chat_id,user_id,message_id) WHERE message_id IS NOT NULL;
        CREATE TABLE IF NOT EXISTS moderation_migrations(
            chat_id TEXT PRIMARY KEY,migrated_at REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS challenge_history(
            chat_id TEXT NOT NULL,user_id TEXT NOT NULL,question_ids_json TEXT NOT NULL DEFAULT '[]',
            last_category TEXT,updated_at REAL NOT NULL,PRIMARY KEY(chat_id,user_id));
        ''');
        # Migrations for databases created by older HichanX versions.
        cols = {r['name'] for r in self.db.execute("PRAGMA table_info(groups)").fetchall()}
        if 'plan' not in cols: self.db.execute("ALTER TABLE groups ADD COLUMN plan TEXT DEFAULT 'normal'")
        if 'subscription_until' not in cols: self.db.execute("ALTER TABLE groups ADD COLUMN subscription_until REAL DEFAULT 0")
        if 'subscription_type' not in cols: self.db.execute("ALTER TABLE groups ADD COLUMN subscription_type TEXT DEFAULT 'normal'")
        # Old releases imposed UNIQUE(chat_id,status), which prevented a group
        # from ever receiving a second approved/rejected request. Replace that
        # constraint with the actual invariant: at most one pending request.
        legacy_unique = False
        for index in self.db.execute("PRAGMA index_list(install_requests)").fetchall():
            if not index['unique']:
                continue
            columns = [
                r['name'] for r in self.db.execute(
                    f"PRAGMA index_info('{index['name']}')"
                ).fetchall()
            ]
            if columns == ['chat_id', 'status']:
                legacy_unique = True
                break
        if legacy_unique:
            self.db.execute("BEGIN IMMEDIATE")
            try:
                self.db.execute("ALTER TABLE install_requests RENAME TO install_requests_legacy")
                self.db.execute("""CREATE TABLE install_requests(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    chat_id TEXT NOT NULL,title TEXT,requester_splus_id TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'pending',created_at REAL,
                    reviewed_at REAL,reviewer TEXT)""")
                self.db.execute("""INSERT INTO install_requests
                    (id,chat_id,title,requester_splus_id,status,created_at,reviewed_at,reviewer)
                    SELECT id,chat_id,title,requester_splus_id,status,created_at,reviewed_at,reviewer
                    FROM install_requests_legacy""")
                self.db.execute("DROP TABLE install_requests_legacy")
                self.db.commit()
            except Exception:
                self.db.rollback()
                raise
        # Preserve request history; only pending requests are unique per group.
        self.db.execute("""CREATE UNIQUE INDEX IF NOT EXISTS
            idx_install_requests_one_pending ON install_requests(chat_id)
            WHERE status='pending'""")
        self.db.commit()

    def record_moderation_violation(self, chat_id, user_id, message_id, category, reason, limit=20000):
        """Atomically deduplicate one message and update user/category strike counts."""
        chat_id, user_id = str(chat_id), str(user_id)
        message_id = None if message_id is None else str(message_id)
        category = str(category or 'other')[:80]
        reason = str(reason or '')[:500]
        now = time.time()
        self.db.execute("BEGIN IMMEDIATE")
        try:
            cursor = self.db.execute(
                "INSERT OR IGNORE INTO moderation_events"
                "(chat_id,user_id,message_id,category,reason,created_at) VALUES(?,?,?,?,?,?)",
                (chat_id, user_id, message_id, category, reason, now),
            )
            inserted = cursor.rowcount > 0
            if inserted:
                self.db.execute(
                    "INSERT INTO moderation_state(chat_id,user_id,strikes,updated_at) VALUES(?,?,1,?) "
                    "ON CONFLICT(chat_id,user_id) DO UPDATE SET strikes=strikes+1,updated_at=excluded.updated_at",
                    (chat_id, user_id, now),
                )
                self.db.execute(
                    "INSERT INTO moderation_categories(chat_id,user_id,category,count,updated_at) "
                    "VALUES(?,?,?,1,?) ON CONFLICT(chat_id,user_id,category) "
                    "DO UPDATE SET count=count+1,updated_at=excluded.updated_at",
                    (chat_id, user_id, category, now),
                )
                self.db.execute(
                    "DELETE FROM moderation_events WHERE created_at<? AND id NOT IN "
                    "(SELECT id FROM moderation_events ORDER BY id DESC LIMIT ?)",
                    (now - 90 * 86400, max(100, int(limit))),
                )
            state = self.db.execute(
                "SELECT strikes FROM moderation_state WHERE chat_id=? AND user_id=?",
                (chat_id, user_id),
            ).fetchone()
            category_row = self.db.execute(
                "SELECT count FROM moderation_categories WHERE chat_id=? AND user_id=? AND category=?",
                (chat_id, user_id, category),
            ).fetchone()
            self.db.commit()
            return {
                "inserted": inserted,
                "strikes": int(state["strikes"]) if state else 0,
                "category_count": int(category_row["count"]) if category_row else 0,
            }
        except Exception:
            self.db.rollback()
            raise

    def moderation_strikes(self, chat_id, user_id):
        row = self.db.execute(
            "SELECT strikes FROM moderation_state WHERE chat_id=? AND user_id=?",
            (str(chat_id), str(user_id)),
        ).fetchone()
        return int(row["strikes"]) if row else 0

    def moderation_strikes_for_chat(self, chat_id):
        rows = self.db.execute(
            "SELECT user_id,strikes FROM moderation_state "
            "WHERE chat_id=? AND strikes>0 ORDER BY strikes DESC,user_id",
            (str(chat_id),),
        ).fetchall()
        return {str(row["user_id"]): int(row["strikes"]) for row in rows}

    def moderation_category_counts(self, chat_id, user_id):
        rows = self.db.execute(
            "SELECT category,count FROM moderation_categories WHERE chat_id=? AND user_id=? ORDER BY category",
            (str(chat_id), str(user_id)),
        ).fetchall()
        return {str(row["category"]): int(row["count"]) for row in rows}

    def reset_moderation_strikes(self, chat_id, user_id):
        """Clear active strikes after an administrator lifts the mute; keep audit totals."""
        self.db.execute(
            "UPDATE moderation_state SET strikes=0,updated_at=? WHERE chat_id=? AND user_id=?",
            (time.time(), str(chat_id), str(user_id)),
        )
        self.db.commit()

    def reset_all_moderation_strikes(self, chat_id):
        self.db.execute(
            "UPDATE moderation_state SET strikes=0,updated_at=? WHERE chat_id=?",
            (time.time(), str(chat_id)),
        )
        self.db.commit()

    def import_legacy_warning_counts(self, chat_id, warning_counts):
        """Import the old JSON warning file once, without overwriting newer DB state."""
        chat_id = str(chat_id)
        now = time.time()
        self.db.execute("BEGIN IMMEDIATE")
        try:
            cursor = self.db.execute(
                "INSERT OR IGNORE INTO moderation_migrations(chat_id,migrated_at) VALUES(?,?)",
                (chat_id, now),
            )
            if cursor.rowcount:
                for user_id, count in (warning_counts or {}).items():
                    try:
                        count = max(0, int(count or 0))
                    except (TypeError, ValueError):
                        continue
                    if not count:
                        continue
                    user_id = str(user_id)
                    self.db.execute(
                        "INSERT INTO moderation_state(chat_id,user_id,strikes,updated_at) VALUES(?,?,?,?) "
                        "ON CONFLICT(chat_id,user_id) DO UPDATE SET "
                        "strikes=MAX(strikes,excluded.strikes),updated_at=excluded.updated_at",
                        (chat_id, user_id, count, now),
                    )
                    self.db.execute(
                        "INSERT INTO moderation_categories(chat_id,user_id,category,count,updated_at) "
                        "VALUES(?,?,'legacy',?,?) ON CONFLICT(chat_id,user_id,category) "
                        "DO UPDATE SET count=MAX(count,excluded.count),updated_at=excluded.updated_at",
                        (chat_id, user_id, count, now),
                    )
            self.db.commit()
            return bool(cursor.rowcount)
        except Exception:
            self.db.rollback()
            raise

    def mutes_for_chat(self, chat_id):
        return self.db.execute(
            "SELECT * FROM mutes WHERE chat_id=? ORDER BY user_id", (str(chat_id),)
        ).fetchall()

    def import_legacy_mutes(self, chat_id, temporary, permanent):
        """Import old JSON mute state once; SQLite is authoritative afterward."""
        chat_id = str(chat_id)
        now = time.time()
        imported = {}
        for user_id, expiry in (temporary or {}).items():
            try:
                expiry = float(expiry)
            except (TypeError, ValueError):
                continue
            if expiry > now:
                imported[str(user_id)] = expiry
        for user_id in (permanent or ()):
            imported[str(user_id)] = None

        self.db.execute("BEGIN IMMEDIATE")
        try:
            cursor = self.db.execute(
                "INSERT OR IGNORE INTO mute_migrations(chat_id,migrated_at) VALUES(?,?)",
                (chat_id, now),
            )
            if cursor.rowcount:
                for user_id, expiry in imported.items():
                    self.db.execute(
                        "INSERT OR IGNORE INTO mutes(chat_id,user_id,until_ts) VALUES(?,?,?)",
                        (chat_id, user_id, expiry),
                    )
            self.db.commit()
            return bool(cursor.rowcount)
        except Exception:
            self.db.rollback()
            raise

    def set_challenge_history(self, chat_id, user_id, question_ids, last_category):
        payload = json.dumps(list(question_ids or []), ensure_ascii=False)
        self.db.execute(
            "INSERT INTO challenge_history(chat_id,user_id,question_ids_json,last_category,updated_at) "
            "VALUES(?,?,?,?,?) ON CONFLICT(chat_id,user_id) DO UPDATE SET "
            "question_ids_json=excluded.question_ids_json,last_category=excluded.last_category,"
            "updated_at=excluded.updated_at",
            (str(chat_id), str(user_id), payload, last_category, time.time()),
        )
        self.db.commit()

    def get_challenge_history(self, chat_id, user_id):
        row = self.db.execute(
            "SELECT question_ids_json,last_category FROM challenge_history WHERE chat_id=? AND user_id=?",
            (str(chat_id), str(user_id)),
        ).fetchone()
        if not row:
            return {"ids": [], "category": None}
        try:
            ids = json.loads(row["question_ids_json"] or "[]")
            if not isinstance(ids, list):
                ids = []
        except (TypeError, ValueError):
            ids = []
        return {"ids": [str(value) for value in ids], "category": row["last_category"]}

    def register_account(self, phone, session_path, active=1):
        self.db.execute(
            "INSERT INTO accounts(phone,session_path,active,last_login,created_at) VALUES(?,?,?,?,COALESCE((SELECT created_at FROM accounts WHERE phone=?),?)) "
            "ON CONFLICT(phone) DO UPDATE SET session_path=excluded.session_path,active=excluded.active,last_login=excluded.last_login",
            (str(phone), str(session_path), int(bool(active)), time.time() if active else None, str(phone), time.time())
        )
        self.db.commit()

    def set_account_active(self, phone, active):
        self.db.execute("UPDATE accounts SET active=?,last_login=CASE WHEN ?=1 THEN ? ELSE last_login END WHERE phone=?",
                        (int(bool(active)), int(bool(active)), time.time(), str(phone)))
        self.db.commit()

    def active_accounts(self):
        return self.db.execute("SELECT * FROM accounts WHERE active=1 ORDER BY last_login DESC").fetchall()

    def accounts(self):
        return self.db.execute("SELECT * FROM accounts ORDER BY last_login DESC, created_at DESC").fetchall()

    def set_setting(self,k,v): self.db.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(k,str(v))); self.db.commit()
    def get_auth_last_request(self, phone):
        v=self.get_setting('auth:last_request:'+str(phone), '')
        try: return float(v) if v else 0.0
        except Exception: return 0.0
    def set_auth_last_request(self, phone, ts=None):
        self.set_setting('auth:last_request:'+str(phone), ts if ts is not None else time.time())
    def clear_auth_last_request(self, phone):
        self.db.execute('DELETE FROM settings WHERE key=?', ('auth:last_request:'+str(phone),)); self.db.commit()
    def get_setting(self,k,d=None):
        r=self.db.execute('SELECT value FROM settings WHERE key=?',(k,)).fetchone(); return r['value'] if r else d
    def create_install_request(self, chat_id, title, requester_splus_id):
        existing = self.get_group(chat_id)
        if existing and int(existing['enabled'] or 0):
            return ('approved', None)
        row = self.db.execute(
            "SELECT * FROM install_requests WHERE chat_id=? AND status='pending' ORDER BY id DESC LIMIT 1",
            (str(chat_id),)
        ).fetchone()
        if row:
            return ('pending', row)
        try:
            cur = self.db.execute(
                "INSERT INTO install_requests(chat_id,title,requester_splus_id,status,created_at) VALUES(?,?,?,?,?)",
                (str(chat_id), str(title), str(requester_splus_id), 'pending', time.time())
            )
            self.db.commit()
        except sqlite3.IntegrityError:
            self.db.rollback()
            row = self.db.execute(
                "SELECT * FROM install_requests WHERE chat_id=? AND status='pending' ORDER BY id DESC LIMIT 1",
                (str(chat_id),)
            ).fetchone()
            if row:
                return ('pending', row)
            raise
        return ('created', self.db.execute("SELECT * FROM install_requests WHERE id=?", (cur.lastrowid,)).fetchone())

    def pending_install_requests(self):
        return self.db.execute("SELECT * FROM install_requests WHERE status='pending' ORDER BY created_at ASC").fetchall()

    def get_install_request(self, request_id):
        return self.db.execute("SELECT * FROM install_requests WHERE id=?", (int(request_id),)).fetchone()

    def review_install_request(self, request_id, approved, reviewer, install=True):
        self.db.execute("BEGIN IMMEDIATE")
        try:
            row = self.get_install_request(request_id)
            if not row or row['status'] != 'pending':
                self.db.rollback()
                return None
            status = 'approved' if approved else 'rejected'
            cur = self.db.execute(
                "UPDATE install_requests SET status=?,reviewed_at=?,reviewer=? WHERE id=? AND status='pending'",
                (status, time.time(), str(reviewer), int(request_id))
            )
            if cur.rowcount != 1:
                self.db.rollback()
                return None
            if approved and install:
                self.db.execute(
                    "INSERT OR IGNORE INTO groups(chat_id,title,installed_by,created_at) VALUES(?,?,?,?)",
                    (str(row['chat_id']), row['title'] or 'گروه',
                     str(row['requester_splus_id']), time.time())
                )
            self.db.commit()
        except Exception:
            self.db.rollback()
            raise
        return self.get_install_request(request_id)

    def approve_install_pending_plan(self, request_id, reviewer):
        return self.review_install_request(request_id, True, reviewer, install=False)

    def set_group_subscription(self, chat_id, duration_days, bot_type='normal', reviewer=None):
        """Set subscription duration and feature tier for one group."""
        cid = str(chat_id)
        until = 0 if duration_days in (None, 0) else time.time() + float(duration_days) * 86400
        plan = 'smart' if str(bot_type).lower() == 'smart' else 'normal'
        row = self.get_group(cid)
        if not row:
            return None
        self.db.execute("UPDATE groups SET enabled=1,plan=?,subscription_until=?,subscription_type=? WHERE chat_id=?",
                        (plan, until, plan, cid))
        self.db.commit()
        return self.get_group(cid)

    def expire_group_if_needed(self, chat_id):
        row = self.get_group(chat_id)
        if not row: return False
        until = float(row['subscription_until'] or 0)
        if until > 0 and until <= time.time() and int(row['enabled'] or 0):
            self.set_group_enabled(chat_id, False)
            return True
        return False

    def install_request_counts(self):
        return {
            'pending': self.db.execute("SELECT COUNT(*) c FROM install_requests WHERE status='pending'").fetchone()['c'],
            'approved': self.db.execute("SELECT COUNT(*) c FROM install_requests WHERE status='approved'").fetchone()['c'],
            'rejected': self.db.execute("SELECT COUNT(*) c FROM install_requests WHERE status='rejected'").fetchone()['c'],
        }

    def install_group(self,chat_id,owner_id,title=''):
        self.db.execute('INSERT OR IGNORE INTO groups(chat_id,title,installed_by,created_at) VALUES(?,?,?,?)',(str(chat_id),title,str(owner_id),time.time())); self.db.commit()
    def get_group(self,cid): return self.db.execute('SELECT * FROM groups WHERE chat_id=?',(str(cid),)).fetchone()
    def groups(self): return self.db.execute('SELECT * FROM groups ORDER BY title COLLATE NOCASE').fetchall()
    def set_group_enabled(self,cid,en): self.db.execute('UPDATE groups SET enabled=? WHERE chat_id=?',(int(bool(en)),str(cid))); self.db.commit()
    def set_group_admin(self,cid,uid,role='admin',telegram_user_id=None):
        self.db.execute('''INSERT INTO group_admins(chat_id,splus_user_id,role,telegram_user_id,created_at) VALUES(?,?,?,?,?)
        ON CONFLICT(chat_id,splus_user_id) DO UPDATE SET role=excluded.role,telegram_user_id=COALESCE(excluded.telegram_user_id,group_admins.telegram_user_id)''',(str(cid),str(uid),role,telegram_user_id,time.time())); self.db.commit()
    def remove_group_admin(self,cid,uid): self.db.execute('DELETE FROM group_admins WHERE chat_id=? AND splus_user_id=?',(str(cid),str(uid))); self.db.commit()
    def get_group_admin(self,cid,uid): return self.db.execute('SELECT * FROM group_admins WHERE chat_id=? AND splus_user_id=?',(str(cid),str(uid))).fetchone()
    def list_admins(self,cid): return self.db.execute('SELECT * FROM group_admins WHERE chat_id=? ORDER BY role DESC',(str(cid),)).fetchall()
    def link_telegram_admin(self,tgid,cid,splus_uid):
        self.db.execute('INSERT INTO telegram_group_links(telegram_user_id,chat_id,splus_user_id,created_at) VALUES(?,?,?,?) ON CONFLICT(telegram_user_id,chat_id) DO UPDATE SET splus_user_id=excluded.splus_user_id',(int(tgid),str(cid),str(splus_uid),time.time())); self.db.commit()
    def unlink_telegram_admin(self,tgid,cid): self.db.execute('DELETE FROM telegram_group_links WHERE telegram_user_id=? AND chat_id=?',(int(tgid),str(cid))); self.db.commit()
    def is_group_admin(self,tgid,cid):
        return bool(self.db.execute('SELECT 1 FROM telegram_group_links l JOIN group_admins a ON a.chat_id=l.chat_id AND a.splus_user_id=l.splus_user_id WHERE l.telegram_user_id=? AND l.chat_id=?',(int(tgid),str(cid))).fetchone())
    def managed_groups(self,tgid): return self.db.execute('SELECT g.* FROM groups g JOIN telegram_group_links l ON l.chat_id=g.chat_id WHERE l.telegram_user_id=? ORDER BY g.title COLLATE NOCASE',(int(tgid),)).fetchall()
    def set_mute(self,cid,uid,until): self.db.execute('INSERT INTO mutes VALUES(?,?,?) ON CONFLICT(chat_id,user_id) DO UPDATE SET until_ts=excluded.until_ts',(str(cid),str(uid),until)); self.db.commit()
    def get_mute(self,cid,uid): return self.db.execute('SELECT * FROM mutes WHERE chat_id=? AND user_id=?',(str(cid),str(uid))).fetchone()
    def remove_mute(self,cid,uid): self.db.execute('DELETE FROM mutes WHERE chat_id=? AND user_id=?',(str(cid),str(uid))); self.db.commit()
    def expired_mutes(self): return self.db.execute('SELECT * FROM mutes WHERE until_ts IS NOT NULL AND until_ts<=?',(time.time(),)).fetchall()
    def add_points(self,cid,uid,n=1): self.db.execute('INSERT INTO points VALUES(?,?,?) ON CONFLICT(chat_id,user_id) DO UPDATE SET points=points+excluded.points',(str(cid),str(uid),n)); self.db.commit()
    def get_points(self,cid,uid):
        r=self.db.execute('SELECT points FROM points WHERE chat_id=? AND user_id=?',(str(cid),str(uid))).fetchone(); return int(r['points']) if r else 0
    def leaderboard(self,cid,limit=10):
        return self.db.execute('SELECT user_id,points FROM points WHERE chat_id=? ORDER BY points DESC LIMIT ?',(str(cid),int(limit))).fetchall()
    def add_filter(self,cid,w): self.db.execute('INSERT OR IGNORE INTO filters VALUES(?,?)',(str(cid),w)); self.db.commit()
    def remove_filter(self,cid,w): self.db.execute('DELETE FROM filters WHERE chat_id=? AND word=?',(str(cid),w)); self.db.commit()
    def filters(self,cid): return [r['word'] for r in self.db.execute('SELECT word FROM filters WHERE chat_id=?',(str(cid),)).fetchall()]
    def settings(self,cid):
        r=self.get_group(cid); return json.loads(r['settings_json'] or '{}') if r else {}
    def update_settings(self,cid,changes):
        s=self.settings(cid); s.update(changes); self.db.execute('UPDATE groups SET settings_json=? WHERE chat_id=?',(json.dumps(s,ensure_ascii=False),str(cid))); self.db.commit()
    def audit(self,actor,scope,action,target='',details=''): self.db.execute('INSERT INTO audit_log(actor,scope,action,target,details,created_at) VALUES(?,?,?,?,?,?)',(str(actor),str(scope),action,str(target),details,time.time())); self.db.commit()
    def stats(self):
        return {'groups':self.db.execute('SELECT COUNT(*) c FROM groups').fetchone()['c'],'admins':self.db.execute('SELECT COUNT(*) c FROM group_admins').fetchone()['c'],'mutes':self.db.execute('SELECT COUNT(*) c FROM mutes').fetchone()['c']}
    def group_stats(self,cid):
        return {'admins':self.db.execute('SELECT COUNT(*) c FROM group_admins WHERE chat_id=?',(str(cid),)).fetchone()['c'],'mutes':self.db.execute('SELECT COUNT(*) c FROM mutes WHERE chat_id=?',(str(cid),)).fetchone()['c'],'points':self.db.execute('SELECT COALESCE(SUM(points),0) c FROM points WHERE chat_id=?',(str(cid),)).fetchone()['c']}

    def close(self):
        self.db.close()

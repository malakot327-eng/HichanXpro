ROLE_LEVEL = {'user': 0, 'admin': 10, 'special_admin': 20, 'owner': 100}

def owner_allowed(telegram_user_id, owner_id):
    return int(telegram_user_id) == int(owner_id)

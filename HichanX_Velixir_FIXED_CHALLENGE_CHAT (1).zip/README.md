# HichanX — Velixir Safe Login Build

Start command:

    python bot.py

Python: 3.11+

This build uses a single authentication worker at a time, a persistent 120-second per-phone login request cooldown, explicit cancellation, and no automatic re-request of a login code after a failed attempt. The Telegram owner panel waits for SplusPy to actually request input before asking the owner for the code.

Environment variables supported:
- TELEGRAM_BOT_TOKEN (or BOT_TOKEN)
- OWNER_TELEGRAM_ID
- SPLUS_SESSION
- DB_PATH

No credential file is included. Configure the environment variables in the workspace Secrets tool; do not commit `.env` files or paste credentials into chat.

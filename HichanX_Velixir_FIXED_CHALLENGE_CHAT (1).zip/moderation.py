"""Shared, dependency-free text normalization and moderation checks."""

from __future__ import annotations

import re
import time
import unicodedata
from collections import defaultdict, deque


_CHAR_MAP = str.maketrans({
    "ي": "ی", "ى": "ی", "ك": "ک", "ۀ": "ه", "ة": "ه",
    "ؤ": "و", "إ": "ا", "أ": "ا", "ٱ": "ا", "ئ": "ی",
    # Common Cyrillic/Greek lookalikes used to disguise Latin URLs.
    "а": "a", "е": "e", "о": "o", "р": "p", "с": "c",
    "х": "x", "у": "y", "і": "i", "ј": "j", "к": "k",
    "м": "m", "т": "t", "в": "b", "н": "h",
    "Α": "a", "Β": "b", "Ε": "e", "Ι": "i", "Κ": "k",
    "Μ": "m", "Ν": "n", "Ο": "o", "Ρ": "p", "Τ": "t",
    "Χ": "x", "Υ": "y",
})
_INVISIBLE = {
    "\u061c", "\u180e", "\u200b", "\u200c", "\u200d", "\u200e",
    "\u200f", "\u202a", "\u202b", "\u202c", "\u202d", "\u202e",
    "\u2060", "\u2066", "\u2067", "\u2068", "\u2069", "\ufeff",
}
_LEET = str.maketrans({"0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t"})
_DIACRITICS = re.compile(r"[\u0300-\u036f\u064b-\u065f\u0670\u06d6-\u06ed]")
_SPACE_RUN = re.compile(r"\s+")
_URL_RE = re.compile(
    r"(?i)(?:https?://|www\.)[^\s<>]+|"
    r"(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+"
    r"(?:com|net|org|edu|gov|mil|int|io|co|me|ly|gg|app|dev|info|biz|"
    r"ir|рус|uk|us|ca|de|fr|ru|xyz|site|online|shop|click|top|link|"
    r"tech|blog|live|tv|pro|ai|cloud|store|club|work|fun)\b"
    r"(?:[/?#][^\s<>]*)?"
)
_HANDLE_RE = re.compile(r"(?<![\w@])@[^\W_][\w]{2,63}", re.UNICODE)
_SPACED_HANDLE_RE = re.compile(r"@\s*([a-z0-9](?:[\W_]*[a-z0-9_]){2,63})", re.I)
_PHONE_RE = re.compile(r"(?<!\d)\+?\d(?:[\d\s().-]{6,}\d)(?!\d)")
_ALNUM_RE = re.compile(r"[^\w]+", re.UNICODE)

_AD_TERMS = (
    "پیوی", "پی وی", "دایرکت", "تبلیغ", "تبلیغات", "عضویت",
    "کسب درآمد", "پورسانت", "فروش ویژه", "ثبت سفارش", "لینک کانال",
    "بیا پیج", "پیجم رو ببین", "فالو بک", "جوین شو",
)
_PROMO_CONTEXT = (
    "فروش", "خرید", "قیمت", "تخفیف", "سفارش", "عضویت", "جوین",
    "فالو", "درآمد", "کانال", "پیج", "تبلیغ", "رایگان",
)
_SHORTENER_DOMAINS = (
    "bitly", "tinyurl", "t.co", "is.gd", "cutt.ly", "shorturl",
    "rebrand.ly", "ow.ly", "buff.ly", "linktr.ee", "rb.gy",
)
_PLATFORM_DOMAINS = (
    "t.me", "telegram.me", "telegram.dog", "tg.me", "splus.ir",
    "instagram.com", "instagr.am", "youtube.com", "youtu.be",
    "facebook.com", "fb.me", "x.com", "twitter.com", "whatsapp.com",
    "wa.me", "discord.gg", "discord.com",
)


def normalize_text(value: object) -> str:
    """Normalize Persian/Arabic Unicode and remove invisible formatting."""
    text = unicodedata.normalize("NFKC", str(value or "")).translate(_CHAR_MAP).lower()
    text = "".join(ch for ch in text if ch not in _INVISIBLE)
    text = _DIACRITICS.sub("", text).replace("ـ", "")
    return _SPACE_RUN.sub(" ", text).strip()


def _compact(value: object, *, leet: bool = False, squash: bool = False) -> str:
    text = normalize_text(value)
    if leet:
        text = text.translate(_LEET)
    text = "".join(ch for ch in text if ch.isalnum())
    if squash:
        text = re.sub(r"(.)\1+", r"\1", text)
    return text


def _phrase_matches(text: str, phrase: str) -> bool:
    target = _compact(phrase)
    if not target:
        return False
    # Permit punctuation, whitespace, and invisible characters between letters,
    # but require word boundaries so short terms do not match ordinary words.
    body = r"[\W_]*".join(re.escape(ch) for ch in target)
    try:
        return re.search(r"(?<!\w)" + body + r"(?!\w)", text, re.UNICODE) is not None
    except re.error:
        return False


def contains_inappropriate(text: object, terms=()) -> bool:
    normalized = normalize_text(text)
    return any(_phrase_matches(normalized, term) for term in terms if str(term or "").strip())


def contains_link_or_contact(text: object, *, profile: bool = False) -> bool:
    normalized = normalize_text(text)
    if not normalized:
        return False
    if _URL_RE.search(normalized):
        return True
    if profile and (_HANDLE_RE.search(normalized) or _SPACED_HANDLE_RE.search(normalized)):
        return True
    compact = _compact(normalized, leet=True, squash=True)
    # Detect service domains even when punctuation, spaces, or repeated letters
    # were inserted between their characters.
    for domain in (*_PLATFORM_DOMAINS, *_SHORTENER_DOMAINS):
        key = _compact(domain, leet=True, squash=True)
        if len(key) >= 3 and key in compact:
            return True
    if profile and _PHONE_RE.search(normalized):
        return True
    return False


def contains_advertising(text: object, *, profile: bool = False, include_links: bool = True) -> bool:
    normalized = normalize_text(text)
    if not normalized:
        return False
    if include_links and contains_link_or_contact(normalized, profile=profile):
        return True
    compact = _compact(normalized)
    matched = {
        _compact(term)
        for term in _AD_TERMS
        if _phrase_matches(normalized, term)
    }
    if matched:
        return True
    # Generic commercial terms only count together, or when a profile is
    # directing visitors to an account/page.
    context_hits = sum(1 for term in _PROMO_CONTEXT if _phrase_matches(normalized, term))
    return context_hits >= 2 or (profile and context_hits >= 1)


class BurstTracker:
    """Bounded in-memory tracker for fast repeated-message spam."""

    def __init__(self, max_users: int = 5000):
        self._events = defaultdict(deque)
        self._max_users = max_users

    def record(self, chat_id, user_id, text, *, now=None, limit=3, window=1.0):
        now = time.monotonic() if now is None else float(now)
        key = (str(chat_id), str(user_id))
        queue = self._events[key]
        cutoff = now - max(0.1, float(window))
        while queue and queue[0][0] < cutoff:
            queue.popleft()
        normalized = _compact(text)
        queue.append((now, normalized))
        repeated = sum(1 for _, previous in queue if normalized and previous == normalized)
        if len(queue) > max(1, int(limit)):
            return True
        if repeated >= 3:
            return True
        if len(self._events) > self._max_users:
            oldest_key = next(iter(self._events))
            if oldest_key != key:
                self._events.pop(oldest_key, None)
        return False
import sys, traceback
from normalizer import normalize_phone

session, raw_phone = sys.argv[1], sys.argv[2]
phone = normalize_phone(raw_phone)
if not phone:
    print('HICHANX_ERROR:شماره موبایل ایران نامعتبر است. نمونه صحیح: +989123456789', flush=True)
    raise SystemExit(1)


def emit(kind, text=''):
    print(f'HICHANX_INPUT:{kind}:{text}', flush=True)


def read_stdin():
    line = sys.stdin.readline()
    if not line:
        raise RuntimeError('ورودی ورود بسته شد.')
    return line.strip()


def main():
    client = None
    try:
        from splusthon.sync import SoroushClient
        client = SoroushClient(session)
        print('HICHANX_STARTED:' + phone, flush=True)

        # Do not use client.start(phone=...) here.  start() owns its own
        # interactive prompt and can block before the panel sees a prompt.
        # Request the code explicitly, then pass the code through stdin.
        try:
            client.connect()
        except TypeError:
            pass

        # A valid existing session should never trigger another login code.
        try:
            authorized = client.is_user_authorized()
            if hasattr(authorized, '__await__'):
                authorized = client.loop.run_until_complete(authorized)
        except Exception:
            authorized = False

        if not authorized:
            sent = client.send_code_request(phone)
            print('HICHANX_CODE_REQUESTED', flush=True)
            emit('code', str(getattr(sent, 'type', '') or ''))
            code = read_stdin()
            try:
                result = client.sign_in(phone=phone, code=code)
                if hasattr(result, '__await__'):
                    result = client.loop.run_until_complete(result)
            except Exception as e:
                name = type(e).__name__
                if name in ('SessionPasswordNeededError','PasswordNeededError'):
                    emit('password', 'رمز دومرحله‌ای')
                    password = read_stdin()
                    result = client.sign_in(password=password)
                    if hasattr(result, '__await__'):
                        result = client.loop.run_until_complete(result)
                else:
                    raise

        print('HICHANX_AUTH_OK:' + phone, flush=True)
        return 0
    except Exception as e:
        name = type(e).__name__
        text = str(e)
        if name in ('PhoneNumberInvalidError','PhoneNumberUnoccupiedError'):
            msg='سروش‌پلاس شماره را معتبر/ثبت‌شده تشخیص نداد. شماره را با فرمت +98 و بدون فاصله بررسی کنید.'
        elif name in ('FloodWaitError','PhoneCodeFloodError','PhoneNumberFloodError'):
            msg='سروش‌پلاس به‌دلیل درخواست‌های زیاد، ورود را موقتاً محدود کرده است. فعلاً درخواست کد جدید نفرستید.'
        elif name in ('PhoneCodeInvalidError','PhoneCodeExpiredError'):
            msg='کد ورود نادرست یا منقضی شده است. کد جدید را فقط از همین ورود وارد کنید.'
        elif name in ('PasswordHashInvalidError','InvalidPasswordError'):
            msg='رمز ورود دومرحله‌ای اشتباه است.'
        else:
            msg=name + ': ' + text
        print('HICHANX_ERROR:' + msg, flush=True)
        traceback.print_exc()
        return 1
    finally:
        if client is not None:
            try:
                f=getattr(client,'disconnect',None) or getattr(client,'stop',None)
                if callable(f):
                    r=f()
                    if hasattr(r, '__await__'):
                        client.loop.run_until_complete(r)
            except Exception:
                pass

raise SystemExit(main())

import random
import sys
import tempfile
import time
import unittest
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from challenge_bank import CHALLENGE_BANK, build_challenge
from database import Database
from moderation import (
    BurstTracker,
    contains_advertising,
    contains_inappropriate,
    contains_link_or_contact,
    normalize_text,
)


class TextModerationTests(unittest.TestCase):
    def test_persian_unicode_and_obfuscation_normalize(self):
        self.assertEqual(normalize_text("ي\u200cك"), "یک")
        self.assertTrue(contains_inappropriate("فـحـش", ("فحش",)))
        self.assertTrue(contains_inappropriate("ف-ح ش", ("فحش",)))

    def test_links_and_advertising_are_found_in_obfuscated_text(self):
        self.assertTrue(contains_link_or_contact("t . me / example"))
        self.assertTrue(contains_link_or_contact("instаgram.com/example"))
        self.assertTrue(contains_link_or_contact("@example_user", profile=True))
        self.assertTrue(contains_advertising("برای تخفیف و خرید ویژه پیام بده"))
        self.assertFalse(contains_advertising("امروز خرید کردم و کتاب خواندم"))

    def test_burst_tracker_detects_repeated_messages(self):
        tracker = BurstTracker()
        self.assertFalse(tracker.record("g", "u", "سلام", now=1.0))
        self.assertFalse(tracker.record("g", "u", "سلام", now=1.1))
        self.assertTrue(tracker.record("g", "u", "سلام", now=1.2))


class ModerationDatabaseTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(str(Path(self.tmp.name) / "test.db"))

    def tearDown(self):
        self.db.close()
        self.tmp.cleanup()

    def test_strikes_categories_and_message_deduplication(self):
        first = self.db.record_moderation_violation(
            "group", "user", 11, "advertising", "ad link"
        )
        duplicate = self.db.record_moderation_violation(
            "group", "user", 11, "advertising", "ad link"
        )
        second = self.db.record_moderation_violation(
            "group", "user", 12, "inappropriate", "bad text"
        )

        self.assertEqual(first, {"inserted": True, "strikes": 1, "category_count": 1})
        self.assertEqual(duplicate["inserted"], False)
        self.assertEqual(duplicate["strikes"], 1)
        self.assertEqual(second["strikes"], 2)
        self.assertEqual(
            self.db.moderation_category_counts("group", "user"),
            {"advertising": 1, "inappropriate": 1},
        )
        self.assertEqual(
            self.db.moderation_strikes_for_chat("group"),
            {"user": 2},
        )

    def test_legacy_strikes_migrate_once_and_can_be_reset(self):
        self.assertTrue(self.db.import_legacy_warning_counts("group", {"user": 2}))
        self.assertFalse(self.db.import_legacy_warning_counts("group", {"user": 9}))
        self.assertEqual(self.db.moderation_strikes("group", "user"), 2)
        self.db.reset_moderation_strikes("group", "user")
        self.assertEqual(self.db.moderation_strikes("group", "user"), 0)

    def test_legacy_mutes_migrate_once_and_database_removal_stays_removed(self):
        expiry = time.time() + 60
        self.assertTrue(
            self.db.import_legacy_mutes("group", {"temporary": expiry}, {"permanent"})
        )
        self.assertFalse(
            self.db.import_legacy_mutes("group", {"permanent": expiry}, {"temporary"})
        )
        self.assertEqual(self.db.get_mute("group", "temporary")["until_ts"], expiry)
        self.assertIsNone(self.db.get_mute("group", "permanent")["until_ts"])

        self.db.remove_mute("group", "permanent")
        self.assertIsNone(self.db.get_mute("group", "permanent"))
        self.assertFalse(
            self.db.import_legacy_mutes("group", {}, {"permanent"})
        )
        self.assertIsNone(self.db.get_mute("group", "permanent"))

    def test_challenge_history_persists_between_database_reads(self):
        ids = ["q-1", "q-2"]
        self.db.set_challenge_history("group", "user", ids, "فضا")
        self.assertEqual(
            self.db.get_challenge_history("group", "user"),
            {"ids": ids, "category": "فضا"},
        )


class ChallengeBankTests(unittest.TestCase):
    def test_requested_subjects_have_diverse_question_sets(self):
        counts = Counter(item["category"] for item in CHALLENGE_BANK)
        for category in (
            "برنامه\u200cنویسی", "رایانه", "هوش و IQ", "زیست\u200cشناسی",
            "فضا", "ورزش", "سینما",
        ):
            self.assertEqual(counts[category], 12, category)
        self.assertEqual(len({item["id"] for item in CHALLENGE_BANK}), len(CHALLENGE_BANK))

    def test_challenges_have_four_distinct_options_and_respect_exclusions(self):
        previous = build_challenge(rng=random.Random(4))
        next_challenge = build_challenge(
            exclude_ids={previous["challenge_id"]},
            exclude_categories={previous["category"]},
            rng=random.Random(5),
        )
        self.assertNotEqual(previous["challenge_id"], next_challenge["challenge_id"])
        self.assertNotEqual(previous["category"], next_challenge["category"])
        self.assertEqual(len(next_challenge["options"]), 4)
        self.assertEqual(len(set(next_challenge["options"])), 4)
        self.assertIn(next_challenge["answer"], next_challenge["options"])
        self.assertEqual(
            next_challenge["options"][next_challenge["answer_index"] - 1],
            next_challenge["answer"],
        )


if __name__ == "__main__":
    unittest.main()
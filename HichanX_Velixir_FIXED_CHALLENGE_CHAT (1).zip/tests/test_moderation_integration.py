import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import hichanx_service as service
from database import Database


class ServiceModerationIntegrationTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(str(Path(self.tmp.name) / "service-test.db"))
        self.chat_id = "test-chat-integration"
        self.user_id = "test-user"
        self.db_patcher = patch.object(service, "MODERATION_DB", self.db)
        self.db_patcher.start()
        self.group_folder_patcher = patch.object(
            service, "group_folder", return_value=self.tmp.name
        )
        self.group_folder_patcher.start()
        service._MUTE_DB_SYNC_TS.pop(self.chat_id, None)
        service.TEMP_MUTES.pop(self.chat_id, None)
        service.PERM_MUTES.pop(self.chat_id, None)
        service.WARNING_COUNTS.pop(self.chat_id, None)
        service._MODERATION_CATEGORY_COUNTS.pop((self.chat_id, self.user_id), None)
        service._HichanX_CHALLENGE_HISTORY.pop(
            service._HichanX_key(self.chat_id, self.user_id), None
        )

    def tearDown(self):
        self.group_folder_patcher.stop()
        self.db_patcher.stop()
        service._MUTE_DB_SYNC_TS.pop(self.chat_id, None)
        service.TEMP_MUTES.pop(self.chat_id, None)
        service.PERM_MUTES.pop(self.chat_id, None)
        service.WARNING_COUNTS.pop(self.chat_id, None)
        service._MODERATION_CATEGORY_COUNTS.pop((self.chat_id, self.user_id), None)
        service._HichanX_CHALLENGE_HISTORY.pop(
            service._HichanX_key(self.chat_id, self.user_id), None
        )
        self.db.close()
        self.tmp.cleanup()

    async def test_third_strike_mutes_and_duplicate_message_counts_once(self):
        background = []
        event = SimpleNamespace(id=1, text="پیام تبلیغاتی")
        message = SimpleNamespace(id=1)
        settings = {"owner": "owner", "admins": []}

        with (
            patch.object(service, "load_warnings"),
            patch.object(
                service, "save_warnings",
                side_effect=[OSError("simulated mirror failure"), None, None],
            ),
            patch.object(service, "push_blackbox"),
            patch.object(service, "increment_stat"),
            patch.object(service, "send_mod_notice", new_callable=AsyncMock) as send_notice,
            patch.object(service, "_spawn_moderation_background",
                         side_effect=lambda coro, _name: background.append(coro)),
            patch.object(service, "save_temp_mutes"),
            patch.object(service, "save_perm_mutes"),
            patch.object(service, "set_user_chat_access",
                         new_callable=AsyncMock, return_value=(True, None)) as set_access,
            patch.object(service, "notify_owner_log", new_callable=AsyncMock),
        ):
            await service._register_moderation_violation(
                None, event, self.chat_id, message, self.chat_id, self.user_id,
                "user", "تبلیغ", category="advertising", already_deleted=True,
                settings=settings,
            )
            await service._register_moderation_violation(
                None, event, self.chat_id, message, self.chat_id, self.user_id,
                "user", "تبلیغ", category="advertising", already_deleted=True,
                settings=settings,
            )
            self.assertEqual(self.db.moderation_strikes(self.chat_id, self.user_id), 1)
            self.assertEqual(send_notice.await_count, 1)

            for message_id in (2, 3):
                event.id = message_id
                message.id = message_id
                await service._register_moderation_violation(
                    None, event, self.chat_id, message, self.chat_id, self.user_id,
                    "user", "تبلیغ", category="advertising", already_deleted=True,
                    settings=settings,
                )

            self.assertEqual(self.db.moderation_strikes(self.chat_id, self.user_id), 3)
            self.assertEqual(
                self.db.moderation_category_counts(self.chat_id, self.user_id),
                {"advertising": 3},
            )
            self.assertTrue(service.is_perm_muted(self.chat_id, self.user_id))
            self.assertEqual(len(background), 1)
            await background.pop()
            set_access.assert_awaited_once()
            self.assertEqual(set_access.await_args.kwargs["allow_send"], False)

    async def test_service_temp_and_permanent_mutes_can_be_lifted(self):
        with patch.object(service, "save_temp_mutes"), patch.object(
            service, "save_perm_mutes"
        ):
            self.assertTrue(service.set_temp_mute(self.chat_id, self.user_id, 1))
            self.assertTrue(service.is_temp_muted(self.chat_id, self.user_id)[0])
            self.assertTrue(service.clear_temp_mute(self.chat_id, self.user_id))
            self.assertFalse(service.is_temp_muted(self.chat_id, self.user_id)[0])

            service.set_perm_mute(self.chat_id, self.user_id)
            self.assertTrue(service.is_perm_muted(self.chat_id, self.user_id))
            self.assertTrue(service.clear_perm_mute(self.chat_id, self.user_id))
            self.assertFalse(service.is_perm_muted(self.chat_id, self.user_id))

    async def test_explicit_false_permission_result_is_not_reported_as_success(self):
        client = SimpleNamespace(edit_permissions=AsyncMock(return_value=False))
        with patch("importlib.import_module", side_effect=ImportError):
            ok, error = await service.set_user_chat_access(
                client, "group", "123", allow_send=False
            )
        self.assertFalse(ok)
        self.assertIn("API returned false", error)

    def test_owner_admin_and_exempt_users_bypass_moderation(self):
        service.EXEMPT_USERS[self.chat_id] = {"exempt-user"}
        try:
            settings = {"owner": "owner-user", "admins": ["admin-user"]}
            self.assertTrue(
                service._moderation_user_exempt(self.chat_id, "owner-user", settings)
            )
            self.assertTrue(
                service._moderation_user_exempt(self.chat_id, "admin-user", settings)
            )
            self.assertTrue(
                service._moderation_user_exempt(self.chat_id, "exempt-user", settings)
            )
            self.assertFalse(
                service._moderation_user_exempt(self.chat_id, "regular-user", settings)
            )
        finally:
            service.EXEMPT_USERS.pop(self.chat_id, None)

    def test_active_public_jokes_are_clean(self):
        jokes = service.PUBLIC_RESPONSES["جوک"]
        self.assertGreaterEqual(len(jokes), 10)
        for joke in jokes:
            for adult_term in ("کیر", "جق", "سکس", "کاندوم"):
                self.assertNotIn(adult_term, joke, joke)
        self.assertIn(service.get_joke_fast(), jokes)

    def test_service_persists_challenge_history_and_varies_subject(self):
        first = service.start_HichanX_challenge(self.chat_id, self.user_id)
        second = service.start_HichanX_challenge(self.chat_id, self.user_id)
        self.assertNotEqual(first["challenge_id"], second["challenge_id"])
        self.assertNotEqual(first["category"], second["category"])
        history = self.db.get_challenge_history(self.chat_id, self.user_id)
        self.assertEqual(
            history["ids"],
            [first["challenge_id"], second["challenge_id"]],
        )
        self.assertEqual(history["category"], second["category"])

    async def test_profile_ad_link_uses_the_central_strike_path(self):
        chat = SimpleNamespace(id=self.chat_id)
        sender = SimpleNamespace(first_name="Tester", last_name="", username=None)
        message = SimpleNamespace(id=101, text="سلام", sender=sender)
        event = SimpleNamespace(
            id=101, text="سلام", sender_id=self.user_id, message=message
        )
        with (
            patch.object(
                service, "_get_user_bio_for_guard",
                new_callable=AsyncMock, return_value="t . me / offers",
            ),
            patch.object(
                service, "_delete_flagged_message",
                new_callable=AsyncMock, return_value=True,
            ),
            patch.object(service, "load_warnings"),
            patch.object(service, "save_warnings"),
            patch.object(service, "push_blackbox"),
            patch.object(service, "increment_stat"),
            patch.object(service, "send_mod_notice", new_callable=AsyncMock),
        ):
            handled = await service.moderate_group_message(
                None, event, chat, message, self.chat_id, self.user_id,
                "Tester", {"owner": "owner", "admins": [], "bio_ad_filter": True},
            )
        self.assertTrue(handled)
        self.assertEqual(self.db.moderation_strikes(self.chat_id, self.user_id), 1)
        self.assertEqual(
            self.db.moderation_category_counts(self.chat_id, self.user_id),
            {"advertising": 1},
        )

    async def test_moderation_notices_are_deleted_after_five_seconds(self):
        sent = SimpleNamespace(delete=AsyncMock())
        client = SimpleNamespace(delete_messages=AsyncMock())
        with patch.object(service.asyncio, "sleep", new_callable=AsyncMock) as sleep:
            await service._delete_moderation_notice_later(client, self.chat_id, sent)
        sleep.assert_awaited_once_with(5)
        sent.delete.assert_awaited_once()

        sent_without_delete = SimpleNamespace(id=123)
        with patch.object(service.asyncio, "sleep", new_callable=AsyncMock):
            await service._delete_moderation_notice_later(
                client, self.chat_id, sent_without_delete
            )
        client.delete_messages.assert_awaited_once_with(self.chat_id, [123])
        self.assertTrue(service._message_needs_auto_delete("اخطار ۱ از ۳"))
        self.assertTrue(service._message_needs_auto_delete("سکوت دائمی ثبت شد"))
        self.assertFalse(service._message_needs_auto_delete("صبح بخیر"))


if __name__ == "__main__":
    unittest.main()

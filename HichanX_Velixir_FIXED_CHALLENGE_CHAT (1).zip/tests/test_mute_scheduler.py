import asyncio
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import scheduler


class MuteSchedulerTests(unittest.IsolatedAsyncioTestCase):
    async def test_expired_mute_is_kept_for_retry_until_unmute_succeeds(self):
        record = {"chat_id": "group", "user_id": "user"}
        db = SimpleNamespace(
            expired_mutes=Mock(side_effect=[[record], [record]]),
            remove_mute=Mock(),
        )
        adapter = SimpleNamespace(
            unmute=AsyncMock(side_effect=[RuntimeError("temporary failure"), None])
        )
        sleep_count = 0

        async def stop_after_retry(_interval):
            nonlocal sleep_count
            sleep_count += 1
            if sleep_count == 2:
                raise asyncio.CancelledError

        with patch.object(scheduler.asyncio, "sleep", side_effect=stop_after_retry):
            with self.assertRaises(asyncio.CancelledError):
                await scheduler.mute_scheduler(db, adapter, interval=10)

        self.assertEqual(adapter.unmute.await_count, 2)
        db.remove_mute.assert_called_once_with("group", "user")

    async def test_false_unmute_result_keeps_expired_mute_record(self):
        record = {"chat_id": "group", "user_id": "user"}
        db = SimpleNamespace(
            expired_mutes=Mock(return_value=[record]),
            remove_mute=Mock(),
        )
        adapter = SimpleNamespace(unmute=AsyncMock(return_value=False))

        with patch.object(
            scheduler.asyncio, "sleep", side_effect=asyncio.CancelledError
        ):
            with self.assertRaises(asyncio.CancelledError):
                await scheduler.mute_scheduler(db, adapter, interval=10)

        adapter.unmute.assert_awaited_once_with("group", "user")
        db.remove_mute.assert_not_called()


if __name__ == "__main__":
    unittest.main()

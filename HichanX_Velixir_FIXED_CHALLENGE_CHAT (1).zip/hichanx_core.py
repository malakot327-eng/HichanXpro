import asyncio, inspect, logging, time
from pathlib import Path
from config import SPLUS_SESSION
from splus_adapter import SplusAdapter

log = logging.getLogger('HichanX.core')

# این مقادیر عمداً محافظه‌کارانه‌اند تا در حالت عادی هیچ مکثی به ربات اضافه نشود.
_WATCHDOG_CHECK_INTERVAL = 5.0
_HEARTBEAT_INTERVAL = 5.0
_HEARTBEAT_TIMEOUT = 8.0
_MAX_HEARTBEAT_FAILURES = 2
_RECOVERY_RETRY_DELAY = 3.0


class HichanXCore:
    def __init__(self, db):
        self.db = db
        self.client = None
        self.adapter = None
        self.task = None
        self.watchdog_task = None
        self._recovery_lock = asyncio.Lock()
        self.enabled = False
        self.ready = False
        self.started_at = None

    def session_exists(self):
        p = Path(SPLUS_SESSION)
        return p.exists() or Path(str(p) + '.session').exists()

    async def _close_client(self, client):
        """بستن امن client قدیمی؛ خطای cleanup نباید recovery را متوقف کند."""
        if not client:
            return
        for n in ('stop', 'disconnect'):
            fn = getattr(client, n, None)
            if callable(fn):
                try:
                    r = fn()
                    if inspect.isawaitable(r):
                        await r
                    break
                except Exception:
                    log.exception('client cleanup failed')
                    break

    async def _create_service(self, SoroushClient):
        """ساخت یک client تازه و اجرای سرویس روی همان client."""
        client = SoroushClient(SPLUS_SESSION)

        r = client.connect()
        if inspect.isawaitable(r):
            await r

        try:
            check = getattr(client, 'is_user_authorized', None)
            if callable(check):
                ok = check()
                if inspect.isawaitable(ok):
                    ok = await ok
                if ok is False:
                    raise RuntimeError(
                        'حساب سروش‌پلاس روی Session مجاز نیست؛ دوباره از «اتصال حساب» وارد شوید.'
                    )
        except RuntimeError:
            raise
        except Exception:
            # نسخه‌های قدیمی SPlusthon ممکن است این متد را نداشته باشند.
            pass

        # main() نباید دوباره connect/start کند و روی همین session
        # یک connection دوم نسازد.
        setattr(client, '_hichanx_lifecycle_started', True)

        from hichanx_service import main as service_main
        task = asyncio.create_task(
            service_main(client, self.db),
            name='hichanx-splus'
        )

        # فقط برای تشخیص خرابی فوری startup؛ در حالت عادی این خواب 0.5s
        # یک بار اجرا می‌شود و هیچ تأخیری در پردازش پیام‌ها ایجاد نمی‌کند.
        await asyncio.sleep(0.5)
        if task.done():
            try:
                exc = task.exception()
            except asyncio.CancelledError:
                exc = None
            if exc:
                await self._close_client(client)
                raise exc
            await self._close_client(client)
            raise RuntimeError('سرویس سروش‌پلاس بلافاصله متوقف شد.')

        return client, task

    async def _restart_after_failure(self, reason='unknown'):
        """بازیابی خودکار سمت Splus بدون نیاز به خاموش/روشن کردن از پنل."""
        if not self.enabled:
            return False

        async with self._recovery_lock:
            if not self.enabled:
                return False

            log.warning('Splus service recovery started: %s', reason)
            self.ready = False

            old_task = self.task
            old_client = self.client
            self.task = None
            self.client = None
            self.adapter = None

            if old_task and not old_task.done():
                old_task.cancel()
                try:
                    await old_task
                except asyncio.CancelledError:
                    pass
                except Exception:
                    log.exception('old Splus task ended with error during recovery')

            await self._close_client(old_client)

            try:
                from splusthon import SoroushClient
            except Exception:
                log.exception('SPlusthon import failed during recovery')
                return False

            try:
                client, task = await self._create_service(SoroushClient)
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception('Splus automatic recovery failed')
                return False

            if not self.enabled:
                # کاربر هم‌زمان از پنل stop زده است؛ connection تازه را رها نمی‌کنیم.
                await self._close_client(client)
                if task and not task.done():
                    task.cancel()
                    try:
                        await task
                    except asyncio.CancelledError:
                        pass
                return False

            self.client = client
            self.adapter = SplusAdapter(client)
            self.task = task
            self.ready = True
            self.started_at = time.time()
            log.info('Splus service recovered automatically')
            return True

    async def _watchdog(self):
        """ناظر سبک: مرگ task یا قطع اتصال طولانی را خودکار بازیابی می‌کند."""
        last_heartbeat = 0.0
        heartbeat_failures = 0

        while self.enabled:
            try:
                await asyncio.sleep(_WATCHDOG_CHECK_INTERVAL)

                if not self.enabled:
                    return

                task = self.task
                client = self.client

                if task is None or task.done() or client is None:
                    await self._restart_after_failure('service task stopped')
                    last_heartbeat = 0.0
                    heartbeat_failures = 0
                    continue

                now = time.monotonic()
                if now - last_heartbeat < _HEARTBEAT_INTERVAL:
                    continue

                # اگر کتابخانه این متد را دارد، یک درخواست سبک برای تشخیص
                # قطع واقعی connection انجام می‌دهیم. timeout مانع گیرکردن watchdog است.
                check = getattr(client, 'get_me', None) or getattr(client, 'me', None)
                if not callable(check):
                    last_heartbeat = now
                    continue

                try:
                    result = check()
                    if inspect.isawaitable(result):
                        await asyncio.wait_for(result, timeout=_HEARTBEAT_TIMEOUT)
                    heartbeat_failures = 0
                    last_heartbeat = now
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    heartbeat_failures += 1
                    log.warning(
                        'Splus heartbeat failed (%d/%d): %s',
                        heartbeat_failures, _MAX_HEARTBEAT_FAILURES, exc
                    )
                    if heartbeat_failures >= _MAX_HEARTBEAT_FAILURES:
                        recovered = await self._restart_after_failure(
                            f'heartbeat failed: {type(exc).__name__}'
                        )
                        if recovered:
                            heartbeat_failures = 0
                            last_heartbeat = 0.0
                        else:
                            last_heartbeat = 0.0

            except asyncio.CancelledError:
                return
            except Exception:
                log.exception('Splus watchdog error')
                await asyncio.sleep(_RECOVERY_RETRY_DELAY)

    async def start(self):
        if self.enabled and self.ready:
            return True, '🟢 HichanX از قبل روشن است.'
        if self.enabled and not self.ready:
            return False, '⏳ HichanX در حال بازیابی اتصال سروش‌پلاس است؛ چند لحظه بعد وضعیت را بررسی کنید.'
        if not self.session_exists():
            return False, '❌ ابتدا از «اتصال حساب» وارد حساب سروش‌پلاس شوید.'
        try:
            from splusthon import SoroushClient
        except Exception as e:
            return False, '❌ SPlusthon نصب/بارگذاری نشد: ' + str(e)[:400]

        try:
            self.enabled = True
            client, task = await self._create_service(SoroushClient)
            self.client = client
            self.adapter = SplusAdapter(client)
            self.task = task
            self.ready = True
            self.started_at = time.time()

            if self.watchdog_task is None or self.watchdog_task.done():
                self.watchdog_task = asyncio.create_task(
                    self._watchdog(),
                    name='hichanx-splus-watchdog'
                )

            log.info('HichanX Soroush service started')
            return True, '🟢 HichanX روشن شد و به حساب سروش‌پلاس متصل است.'
        except Exception as e:
            log.exception('start failed')
            self.enabled = False
            self.ready = False

            task = self.task
            client = self.client
            self.task = None
            self.client = None
            self.adapter = None

            if task and not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
            await self._close_client(client)

            wd = self.watchdog_task
            self.watchdog_task = None
            if wd and not wd.done():
                wd.cancel()
                try:
                    await wd
                except asyncio.CancelledError:
                    pass

            return False, '❌ شروع HichanX ناموفق بود:\n' + str(e)[:900]

    async def stop(self):
        self.enabled = False
        self.ready = False

        wd = self.watchdog_task
        self.watchdog_task = None
        if wd and not wd.done():
            wd.cancel()
            try:
                await wd
            except asyncio.CancelledError:
                pass

        task, client = self.task, self.client
        self.task = None
        self.client = None
        self.adapter = None

        if task and not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
            except Exception:
                log.exception('service task failed while stopping')

        await self._close_client(client)
        return True, '⏹ HichanX خاموش شد.'

    async def status(self):
        acc = None
        if self.client and self.ready:
            try:
                fn = getattr(self.client, 'get_me', None) or getattr(self.client, 'me', None)
                if fn:
                    r = fn()
                    acc = await r if inspect.isawaitable(r) else r
            except Exception:
                pass
        return {
            'enabled': self.enabled,
            'ready': self.ready,
            'account': acc,
            'started_at': self.started_at,
        }

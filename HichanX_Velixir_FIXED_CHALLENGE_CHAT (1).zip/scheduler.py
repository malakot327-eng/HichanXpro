import asyncio


async def mute_scheduler(db,adapter,interval=10):
    while True:
        for r in db.expired_mutes():
            try:
                result = await adapter.unmute(r['chat_id'], r['user_id'])
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                # Keep the expired record so a transient API failure is retried.
                print(f"mute expiry retry {r['chat_id']}/{r['user_id']}: {exc}")
                continue
            if result is False or (
                isinstance(result, tuple) and result and result[0] is False
            ):
                print(f"mute expiry retry {r['chat_id']}/{r['user_id']}: API returned false")
                continue
            db.remove_mute(r['chat_id'], r['user_id'])
        await asyncio.sleep(interval)

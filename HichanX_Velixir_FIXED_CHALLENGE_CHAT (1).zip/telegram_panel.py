import asyncio,logging,sys
from pathlib import Path
from telegram import InlineKeyboardButton,InlineKeyboardMarkup,Update
from telegram.ext import Application,CallbackQueryHandler,CommandHandler,ContextTypes,MessageHandler,filters
from config import TELEGRAM_BOT_TOKEN,OWNER_TELEGRAM_ID,SPLUS_SESSION
from database import Database
log=logging.getLogger('HichanX.panel')
class TelegramPanel:
 def __init__(self,core,db): self.core=core;self.db=db;self.app=None;self.proc=None;self.reader=None;self.auth_chat=None;self.states={};self.auth_prompt_event=None;self.auth_prompt_text='';self.auth_phone=None;self.auth_kind=None;self.auth_lock=asyncio.Lock();self.auth_cooldown=120
 def owner(self,uid):return int(uid)==int(OWNER_TELEGRAM_ID)
 def menu(self):
  st='🟢 روشن' if self.core.enabled else '🔴 خاموش'
  return InlineKeyboardMarkup([[InlineKeyboardButton('⚙️ '+st,callback_data='o:status')],[InlineKeyboardButton('▶️ روشن',callback_data='o:start'),InlineKeyboardButton('⏹ خاموش',callback_data='o:stop')],[InlineKeyboardButton('📱 اتصال حساب',callback_data='o:connect'),InlineKeyboardButton('📞 شماره‌های فعال',callback_data='o:numbers')],[InlineKeyboardButton('👥 گروه‌ها',callback_data='o:groups'),InlineKeyboardButton('📨 درخواست‌ها',callback_data='o:requests')],[InlineKeyboardButton('📢 پیام همگانی',callback_data='o:broadcast')],[InlineKeyboardButton('👮 دسترسی مدیران',callback_data='o:admins')],[InlineKeyboardButton('📊 آمار',callback_data='o:stats')]])
 async def start(self):
  if not TELEGRAM_BOT_TOKEN:raise RuntimeError('TELEGRAM_BOT_TOKEN/BOT_TOKEN is missing')
  self.app=Application.builder().token(TELEGRAM_BOT_TOKEN).build();self.app.add_handler(CommandHandler('start',self.cmd_start));self.app.add_handler(CallbackQueryHandler(self.cb));self.app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND,self.text));await self.app.initialize();await self.app.start();await self.app.updater.start_polling(drop_pending_updates=True);log.info('Telegram polling started')
 async def stop(self):
  if self.proc and self.proc.returncode is None:self.proc.kill()
  if self.app:
   if self.app.updater and self.app.updater.running:await self.app.updater.stop()
   await self.app.stop();await self.app.shutdown()
 async def cmd_start(self,u,c):
  uid=u.effective_user.id
  if self.owner(uid):await u.message.reply_text('🛡 HichanX\nکنترل پنل مالک حساب سروش‌پلاس',reply_markup=self.menu());return
  gs=self.db.managed_groups(uid)
  if gs:await u.message.reply_text('👮 پنل مدیر گروه',reply_markup=self.gmenu(gs))
  else:await u.message.reply_text('⛔ دسترسی ندارید.')
 def gmenu(self,gs):return InlineKeyboardMarkup([[InlineKeyboardButton('👥 '+(g['title'] or g['chat_id']),callback_data='g:'+g['chat_id'])] for g in gs])
 async def cb(self,u,c):
  q=u.callback_query;await q.answer();uid=q.from_user.id;d=q.data or ''
  if d.startswith('o:'):
   if not self.owner(uid):await q.edit_message_text('⛔ دسترسی ندارید.');return
   await self.ocb(q,d[2:]);return
  if d.startswith('leave:'):
   if not self.owner(uid):return
   try:await self.core.adapter.leave_chat(d[6:]);await q.edit_message_text('🚪 از گروه خارج شد.',reply_markup=self.menu())
   except Exception as e:await q.edit_message_text('❌ '+str(e)[:500],reply_markup=self.menu())
   return
  if d.startswith('req:'):
   if not self.owner(uid): return
   rid=d.split(':',1)[1]
   r=self.db.get_install_request(rid)
   if not r or r['status']!='pending':
    await q.edit_message_text('ℹ️ این درخواست قبلاً بررسی شده است.',reply_markup=self.menu());return
   title=r['title'] or r['chat_id']
   kb=InlineKeyboardMarkup([[InlineKeyboardButton('✅ تأیید نصب',callback_data=f'reqok:{rid}'),InlineKeyboardButton('❌ رد درخواست',callback_data=f'reqno:{rid}')],[InlineKeyboardButton('↩️ درخواست‌ها',callback_data='o:requests')]])
   await q.edit_message_text(f'📨 درخواست نصب\n\n👥 گروه: {title}\n🆔 شناسه گروه: {r["chat_id"]}\n👤 درخواست‌کننده: {r["requester_splus_id"]}\n🕐 زمان: {__import__("datetime").datetime.fromtimestamp(r["created_at"]).strftime("%Y/%m/%d %H:%M")}',reply_markup=kb);return
  if d.startswith('reqduration_menu:'):
   if not self.owner(uid): return
   rid=d.split(':',1)[1]
   r=self.db.get_install_request(rid)
   if not r or r['status']!='approved':
    await q.edit_message_text('ℹ️ این درخواست دیگر آماده انتخاب اشتراک نیست.',reply_markup=self.menu());return
   kb=InlineKeyboardMarkup([
      [InlineKeyboardButton('🗓 اشتراک ۱ هفته‌ای',callback_data=f'reqduration:{rid}:7')],
      [InlineKeyboardButton('🗓 اشتراک ۱ ماهه',callback_data=f'reqduration:{rid}:30')],
      [InlineKeyboardButton('🗓 اشتراک ۳ ماهه',callback_data=f'reqduration:{rid}:90')],
      [InlineKeyboardButton('♾️ اشتراک دائمی',callback_data=f'reqduration:{rid}:permanent')],
      [InlineKeyboardButton('↩️ درخواست‌ها',callback_data='o:requests')]
   ])
   await q.edit_message_text('⏳ مدت اشتراک را انتخاب کنید:',reply_markup=kb);return
  if d.startswith('reqduration:'):
   if not self.owner(uid): return
   rid,days=d.split(':',2)[1:]
   r=self.db.get_install_request(rid)
   if not r or r['status']!='approved':
    await q.edit_message_text('ℹ️ این درخواست دیگر آماده انتخاب اشتراک نیست.',reply_markup=self.menu());return
   _days_value = 'p' if days == 'permanent' else str(int(days))
   title=r['title'] or r['chat_id']
   kb=InlineKeyboardMarkup([[InlineKeyboardButton('🟢 ربات معمولی',callback_data=f'reqtype:{rid}:{_days_value}:normal'),InlineKeyboardButton('🤖 ربات هوشمند',callback_data=f'reqtype:{rid}:{_days_value}:smart')],[InlineKeyboardButton('↩️ مدت اشتراک',callback_data=f'reqduration_menu:{rid}')]])
   await q.edit_message_text(f'🤖 نوع ربات را برای گروه «{title}» انتخاب کنید:\n\n🟢 ربات معمولی: فقط امکانات معمولی\n🤖 ربات هوشمند: امکانات معمولی + تمام امکانات PRO',reply_markup=kb);return
  if d.startswith('reqtype:'):
   if not self.owner(uid): return
   parts=d.split(':');rid=parts[1];days_raw=parts[2];bot_type=parts[3]
   days=None if days_raw=='p' else int(days_raw)
   r=self.db.get_install_request(rid)
   if not r or r['status']!='approved':
    await q.edit_message_text('ℹ️ این درخواست دیگر آماده فعال‌سازی نیست.',reply_markup=self.menu());return
   self.db.install_group(r['chat_id'],r['requester_splus_id'],r['title'] or 'گروه')
   self.db.set_group_subscription(r['chat_id'],days,bot_type,uid)
   self.db.audit(uid,r['chat_id'],'subscription_activated',target=r['requester_splus_id'],details=f'{bot_type}:{days or "permanent"}')
   self.states.pop(uid,None)
   if self.core.adapter:
    try:
     if days is None: exp='دائمی ♾️'
     else: exp=f'{days} روزه'
     kind='🤖 هوشمند' if bot_type=='smart' else '🟢 معمولی'
     await self.core.adapter.send_message(r['chat_id'],f'✅ اشتراک HichanX فعال شد.\n\n⏳ مدت: {exp}\n{kind}')
    except Exception: pass
   title=r['title'] or r['chat_id']
   await q.edit_message_text(f'✅ اشتراک گروه فعال شد.\n\n👥 {title}\n⏳ مدت: {"دائمی ♾️" if days is None else str(days)+" روزه"}\n🤖 نوع: {"هوشمند" if bot_type=="smart" else "معمولی"}',reply_markup=self.menu());return
  if d.startswith('reqok:') or d.startswith('reqno:'):
   if not self.owner(uid): return
   approved=d.startswith('reqok:');rid=d.split(':',1)[1]
   if approved:
    r=self.db.approve_install_pending_plan(rid,uid)
    if not r:
     await q.edit_message_text('ℹ️ این درخواست قبلاً بررسی شده است.',reply_markup=self.menu());return
    title=r['title'] or r['chat_id']
    self.db.audit(uid,r['chat_id'],'install_approved_waiting_subscription',target=r['requester_splus_id'],details=title)
    kb=InlineKeyboardMarkup([
      [InlineKeyboardButton('🗓 اشتراک ۱ هفته‌ای',callback_data=f'reqduration:{rid}:7')],
      [InlineKeyboardButton('🗓 اشتراک ۱ ماهه',callback_data=f'reqduration:{rid}:30')],
      [InlineKeyboardButton('🗓 اشتراک ۳ ماهه',callback_data=f'reqduration:{rid}:90')],
      [InlineKeyboardButton('♾️ اشتراک دائمی',callback_data=f'reqduration:{rid}:permanent')],
      [InlineKeyboardButton('↩️ درخواست‌ها',callback_data='o:requests')]
    ])
    await q.edit_message_text(f'✅ درخواست نصب تأیید شد.\n\n👥 {title}\n\n⏳ مدت اشتراک را انتخاب کنید:',reply_markup=kb);return
   r=self.db.review_install_request(rid,False,uid)
   if not r:
    await q.edit_message_text('ℹ️ این درخواست قبلاً بررسی شده است.',reply_markup=self.menu());return
   title=r['title'] or r['chat_id']
   self.db.audit(uid,r['chat_id'],'install_rejected',target=r['requester_splus_id'],details=title)
   if self.core.adapter:
    try: await self.core.adapter.send_message(r['chat_id'],'❌ درخواست نصب HichanX رد شد.')
    except Exception: pass
   await q.edit_message_text('❌ درخواست رد شد.\n\n👥 '+str(title),reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('↩️ درخواست‌ها',callback_data='o:requests')],[InlineKeyboardButton('🏠 پنل اصلی',callback_data='o:status')]]));return
  if d.startswith('ogadmin:'):
   if not self.owner(uid): return
   cid=d.split(':',1)[1]; self.states[uid]=('admin_link',cid); await q.edit_message_text('برای اتصال مدیر، دو مقدار را در یک خط بفرستید:\nSplusUserID TelegramUserID\nمثال: 12345 67890'); return
  if d.startswith('og:'):
   if self.owner(uid):await self.og(q,d[3:])
   return
  if d.startswith('bc:'):
   if self.owner(uid):await self.bc(q,d[3:])
   return
  if d.startswith('g:'):
   cid=d[2:]
   if self.db.is_group_admin(uid,cid):await self.gc(q,cid)
   else:await q.edit_message_text('⛔ این گروه در حوزه شما نیست.')
   return
  if d.startswith('ga:'):
   cid,action=d[3:].split(':',1)
   if not self.db.is_group_admin(uid,cid):await q.edit_message_text('⛔ دسترسی ندارید.');return
   self.states[uid]=('gaction',cid,action);await q.edit_message_text('شناسه کاربر سروش‌پلاس را ارسال کنید. برای پاکسازی، آمار یا تغییر تنظیم ضداسپم/ضدتبلیغ عدد 0 بفرستید.')
 async def ocb(self,q,a):
  if a=='start':ok,msg=await self.core.start();await q.edit_message_text(msg,reply_markup=self.menu());return
  if a=='stop':
   ok,msg=await self.core.stop();await q.edit_message_text(msg,reply_markup=self.menu());return
  if a=='status':
   s=await self.core.status();acc='متصل' if s['account'] else ('در حال اتصال' if self.core.enabled else 'متصل نیست');await q.edit_message_text(f'🛡 وضعیت\nسرویس: {"🟢 روشن" if s["enabled"] else "🔴 خاموش"}\nحساب: {acc}',reply_markup=self.menu());return
  if a=='connect':
   if self.proc and self.proc.returncode is None:
    await q.edit_message_text('🔐 یک ورود در حال انجام است. ابتدا همان ورود را کامل یا لغو کنید.',reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('❌ لغو ورود',callback_data='o:authcancel')],[InlineKeyboardButton('↩️ بازگشت',callback_data='o:status')]]));return
   self.states[q.from_user.id]=('phone',);await q.edit_message_text('📱 شماره حساب شخصی سروش‌پلاس را بفرستید.\nمثال: +989123456789\n\nدر هر لحظه فقط یک درخواست ورود فعال خواهد بود.',reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('❌ لغو',callback_data='o:authcancel')]]));return
  if a=='authcancel':
   await self.cancel_auth(q.from_user.id, q.message.chat_id if q.message else None);return
  if a=='numbers':
   rows=self.db.active_accounts()
   if not rows:
    await q.edit_message_text('📞 هیچ شماره فعالی ثبت نشده است.',reply_markup=self.menu());return
   lines=['📞 شماره‌های فعال HichanX:','']
   for r in rows:
    status='🟢 فعال' if self.core.ready and str(r['session_path'])==str(SPLUS_SESSION) else '⚪ ثبت‌شده'
    lines.append(f"{status}  {r['phone']}")
   await q.edit_message_text('\n'.join(lines),reply_markup=self.menu());return
  if a=='requests':
   rows=self.db.pending_install_requests()
   if not rows:
    await q.edit_message_text('📨 هیچ درخواست نصبی در انتظار بررسی نیست.',reply_markup=self.menu());return
   buttons=[]
   for r in rows[:50]:
    title=(r['title'] or r['chat_id'])[:28]
    buttons.append([InlineKeyboardButton('⏳ '+title,callback_data=f'req:{r["id"]}')])
   buttons.append([InlineKeyboardButton('↩️ بازگشت',callback_data='o:status')])
   await q.edit_message_text(f'📨 درخواست‌های نصب\nتعداد در انتظار: {len(rows)}\n\nروی هر درخواست بزنید:',reply_markup=InlineKeyboardMarkup(buttons));return
  if a=='groups':
   if not self.core.adapter:await q.edit_message_text('ابتدا حساب را وصل و سپس روشن کنید.',reply_markup=self.menu());return
   try:
    rows=[]
    for x in (await self.core.adapter.chats()) or []:
     cid=getattr(x,'id',getattr(x,'chat_id',None));title=getattr(x,'title',getattr(x,'name',cid))
     if cid is not None:rows.append([InlineKeyboardButton('👥 '+str(title)[:35],callback_data='og:'+str(cid))])
    await q.edit_message_text('👥 گروه‌های حساب',reply_markup=InlineKeyboardMarkup(rows[:50]+[[InlineKeyboardButton('↩️ بازگشت',callback_data='o:status')]]))
   except Exception as e:await q.edit_message_text('❌ دریافت گروه‌ها: '+str(e)[:500],reply_markup=self.menu())
   return
  if a=='broadcast':self.states[q.from_user.id]=('broadcast',);await q.edit_message_text('📢 متن پیام همگانی را بفرستید.');return
  if a=='admins':
   gs=self.db.groups();rows=[[InlineKeyboardButton('👥 '+(g['title'] or g['chat_id']),callback_data='ogadmin:'+g['chat_id'])] for g in gs];await q.edit_message_text('👮 گروه را برای مدیریت دسترسی انتخاب کنید.',reply_markup=InlineKeyboardMarkup(rows[:50] or [[InlineKeyboardButton('↩️ بازگشت',callback_data='o:status')]]));return
  if a=='stats':s=self.db.stats();await q.edit_message_text(f'📊 گروه‌ها: {s["groups"]}\nمدیران: {s["admins"]}\nمیوت‌ها: {s["mutes"]}',reply_markup=self.menu());return
 async def og(self,q,cid):
  g=self.db.get_group(cid);await q.edit_message_text(f'👥 {g["title"] if g else cid}',reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('🚪 ترک گروه',callback_data='leave:'+cid)],[InlineKeyboardButton('↩️ بازگشت',callback_data='o:groups')]]))
 async def gc(self,q,cid):
  g=self.db.get_group(cid);t=g['title'] if g else cid
  kb=InlineKeyboardMarkup([[InlineKeyboardButton('👥 اعضا',callback_data=f'ga:{cid}:members'),InlineKeyboardButton('👮 ادمین‌ها',callback_data=f'ga:{cid}:admins')],[InlineKeyboardButton('🚫 بن',callback_data=f'ga:{cid}:ban'),InlineKeyboardButton('🔇 میوت',callback_data=f'ga:{cid}:mute')],[InlineKeyboardButton('🧹 پاکسازی',callback_data=f'ga:{cid}:cleanup')],[InlineKeyboardButton('🛡 ضداسپم',callback_data=f'ga:{cid}:antispam'),InlineKeyboardButton('📢 ضدتبلیغ',callback_data=f'ga:{cid}:antiad')],[InlineKeyboardButton('🔤 فیلتر کلمات',callback_data=f'ga:{cid}:filter'),InlineKeyboardButton('📊 آمار',callback_data=f'ga:{cid}:stats')]])
  await q.edit_message_text(f'👮 {t}\nشناسه: {cid}',reply_markup=kb)
 async def text(self,u,c):
  uid=u.effective_user.id;st=self.states.get(uid);txt=(u.message.text or '').strip()
  if not st:return
  if st[0]=='phone' and self.owner(uid):
   from normalizer import normalize_phone
   phone=normalize_phone(txt)
   if not phone:
    await u.message.reply_text('❌ شماره نامعتبر است.\nفرمت درست: +989123456789');return
   try:
    await self.begin_auth(u.effective_chat.id,phone)
    self.states[uid]=('otp',phone)
    await u.message.reply_text(f'📨 فقط یک درخواست ورود برای {phone} ایجاد شد.\n✉️ کدی که همین حالا دریافت کرده‌اید را بفرستید.\n\nاگر حساب رمز دومرحله‌ای دارد، بعد از کد از شما رمز را می‌خواهم.',reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('❌ لغو ورود',callback_data='o:authcancel')]]))
   except Exception as e:
    self.states.pop(uid,None)
    await u.message.reply_text('❌ شروع ورود انجام نشد:\n'+str(e)[:700])
   return
  if st[0] in ('otp','password') and self.owner(uid):
   await self.auth_input(txt)
   if st[0]=='password':
    await u.message.reply_text('⏳ در حال بررسی رمز دومرحله‌ای؛ درخواست ورود جدیدی ایجاد نمی‌شود.')
   else:
    await u.message.reply_text('⏳ کد دریافت شد؛ در حال تأیید ورود...\n\n⚠️ درخواست کد جدیدی ایجاد نمی‌شود.')
   return
  if st[0]=='broadcast' and self.owner(uid):self.states[uid]=('bc_confirm',txt);await u.message.reply_text('پیام آماده است. ارسال شود؟',reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('✅ ارسال',callback_data='bc:yes'),InlineKeyboardButton('❌ لغو',callback_data='o:status')]]));return
  if st[0]=='admin_link' and self.owner(uid):
   try:
    su,tg=txt.split()[:2]; self.db.set_group_admin(st[1],su,'admin',int(tg)); self.db.link_telegram_admin(int(tg),st[1],su); self.states.pop(uid,None); await u.message.reply_text('✅ مدیر گروه ثبت و به پنل تلگرام متصل شد.',reply_markup=self.menu())
   except Exception as e: await u.message.reply_text('❌ فرمت صحیح: SplusUserID TelegramUserID')
   return
  if st[0]=='filter' and self.db.is_group_admin(uid,st[1]):
   self.db.add_filter(st[1],txt); self.states.pop(uid,None); await u.message.reply_text('✅ کلمه به فیلتر اضافه شد.'); return
  if st[0]=='gaction' and self.db.is_group_admin(uid,st[1]):await self.group_action(uid,st[1],st[2],txt,u)
 async def group_action(self,uid,cid,a,target,u):
  self.states.pop(uid,None)
  if a=='stats':s=self.db.group_stats(cid);await u.message.reply_text(f'📊 ادمین‌ها: {s["admins"]}\nمیوت‌ها: {s["mutes"]}\nامتیازهای ثبت‌شده: {s["points"]}');return
  if a=='filter':self.states[uid]=('filter',cid);await u.message.reply_text('کلمه فیلتر را بفرستید.');return
  if a in ('antispam','antiad'):
   if target!='0':await u.message.reply_text('برای تغییر این تنظیم، عدد 0 بفرستید.');return
   try:
    from hichanx_service import is_pro_active,load_group,save_group
    settings=load_group(cid)
    if a=='antiad':
     if not is_pro_active(settings,cid):
      await u.message.reply_text('⛔ ضدتبلیغ هوشمند فقط برای گروه‌های PRO فعال است.')
      return
     setting_key='smart_adblock'
     enabled=not bool(settings.get(setting_key,False))
     settings[setting_key]=enabled
    else:
     filters_map=settings.setdefault('filters',{})
     setting_key='filters.spam'
     enabled=not bool(filters_map.get('spam',True))
     filters_map['spam']=enabled
    save_group(cid,force=True)
    self.db.audit(uid,cid,a,target=setting_key,details='enabled' if enabled else 'disabled')
    label='ضداسپم' if a=='antispam' else 'ضدتبلیغ'
    await u.message.reply_text(f'⚙️ {label}: {"روشن ✅" if enabled else "خاموش ❌"}')
   except Exception as e:await u.message.reply_text('❌ تغییر تنظیم انجام نشد: '+str(e)[:400])
   return
  try:
   if a=='members':r=await self.core.adapter.participants(cid);await u.message.reply_text('👥 تعداد اعضای دریافتی: '+str(len(r or [])));return
   if a=='admins':r=self.db.list_admins(cid);await u.message.reply_text('👮\n'+'\n'.join(f'{x["splus_user_id"]} — {x["role"]}' for x in r)[:3500] or 'ادمینی ثبت نشده.');return
   if target=='0':await u.message.reply_text('انجام شد.');return
   if a=='ban':await self.core.adapter.ban(cid,target);await u.message.reply_text('🚫 بن شد.');return
   if a=='mute':await self.core.adapter.mute(cid,target);self.db.set_mute(cid,target,None);await u.message.reply_text('🔇 میوت شد.');return
   if a=='cleanup':await u.message.reply_text('🧹 برای پاکسازی گسترده باید پیام‌های مشخص را هدف بگیرید؛ API این نسخه حذف انبوه را به‌صورت امن محدود می‌کند.');return
  except Exception as e:await u.message.reply_text('❌ '+str(e)[:500])
 async def bc(self,q,a):
  if a!='yes':return
  txt=self.states.pop(q.from_user.id,None);txt=txt[1] if isinstance(txt,tuple) and txt[0]=='bc_confirm' else None
  if not txt:await q.edit_message_text('❌ پیام پیدا نشد.',reply_markup=self.menu());return
  ok=fail=0
  for g in self.db.groups():
   try:await self.core.adapter.send_message(g['chat_id'],txt);ok+=1
   except Exception:fail+=1
   await asyncio.sleep(.8)
  await q.edit_message_text(f'📢 ارسال تمام شد\nموفق: {ok}\nناموفق: {fail}',reply_markup=self.menu())
 async def begin_auth(self,chat,phone):
  async with self.auth_lock:
   if self.proc and self.proc.returncode is None:
    raise RuntimeError('یک ورود دیگر فعال است؛ کد جدید درخواست نمی‌شود.')
   import time
   last=self.db.get_auth_last_request(phone)
   remain=self.auth_cooldown-(time.time()-last)
   if remain>0:
    raise RuntimeError(f'برای جلوگیری از ارسال چندباره کد، {int(remain)+1} ثانیه صبر کنید.')
   Path(SPLUS_SESSION).parent.mkdir(parents=True,exist_ok=True)
   self.auth_chat=chat;self.auth_phone=phone;self.auth_kind=None
   self.auth_prompt_event=asyncio.Event();self.auth_prompt_text=''
   self.db.set_auth_last_request(phone)
   self.proc=await asyncio.create_subprocess_exec(sys.executable,str(Path(__file__).with_name('auth_worker.py')),SPLUS_SESSION,phone,stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.STDOUT)
   self.reader=asyncio.create_task(self.read_auth())
   try:
    await asyncio.wait_for(self.auth_prompt_event.wait(),timeout=45)
   except asyncio.TimeoutError:
    if self.proc and self.proc.returncode is None:self.proc.kill()
    raise RuntimeError('سروش‌پلاس در ۴۵ ثانیه درخواست کد نکرد. ورود متوقف شد و کد جدیدی درخواست نمی‌شود.')

 async def cancel_auth(self,uid,chat_id=None):
  if not self.owner(uid): return
  p=self.proc
  self.states.pop(uid,None)
  if p and p.returncode is None:
   try: p.kill()
   except Exception: pass
   try: await p.wait()
   except Exception: pass
  self.proc=None;self.auth_phone=None;self.auth_kind=None;self.auth_prompt_event=None
  target=chat_id or self.auth_chat
  if target:
   await self.app.bot.send_message(target,'❌ ورود لغو شد. تا درخواست بعدی، کد جدیدی ارسال نمی‌شود.',reply_markup=self.menu())

 async def read_auth(self):
  p=self.proc
  try:
   while True:
    line=await p.stdout.readline()
    if not line:break
    s=line.decode(errors='replace').strip();log.info(s)
    if s.startswith('HICHANX_INPUT:'):
     payload=s[len('HICHANX_INPUT:'):]
     parts=payload.split(':',1);reported_kind=parts[0] if parts else 'code';self.auth_prompt_text=parts[1] if len(parts)>1 else ''
     # A second prompt is not automatically 2FA: some versions may ask for the
     # login code again. Use the worker's explicit kind and keep the same attempt.
     self.auth_kind=reported_kind
     if self.auth_prompt_event and not self.auth_prompt_event.is_set(): self.auth_prompt_event.set()
     if self.auth_chat:
      if self.auth_kind=='password':
       self.states[self._owner_id()]=('password',self.auth_phone)
       await self.app.bot.send_message(self.auth_chat,'🔐 این حساب رمز دومرحله‌ای دارد. رمز دوم را همینجا بفرستید.\n\nاین همان ورود قبلی است؛ کد جدیدی درخواست نمی‌شود.',reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('❌ لغو ورود',callback_data='o:authcancel')]]))
      elif self.auth_kind=='code':
       # If this is a retry prompt, do not tell the user that a new SMS was sent.
       await self.app.bot.send_message(self.auth_chat,'🔢 کد ورود را وارد کنید.\n\n⚠️ این مرحله مربوط به همین تلاش ورود است و درخواست ورود جدیدی ایجاد نمی‌شود.',reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('❌ لغو ورود',callback_data='o:authcancel')]]))
    elif s.startswith('HICHANX_AUTH_OK:'):
     phone=s.split(':',1)[1].strip() or self.auth_phone
     if phone:self.db.register_account(phone,SPLUS_SESSION,1);self.db.clear_auth_last_request(phone)
     ok,msg=await self.core.start()
     if self.auth_chat:
      await self.app.bot.send_message(self.auth_chat,('✅ حساب با موفقیت متصل و HichanX روشن شد.\n\n' if ok else '⚠️ ورود حساب موفق بود، اما روشن‌کردن سرویس ناموفق شد:\n')+msg,reply_markup=self.menu())
     self.states.pop(self._owner_id(),None)
    elif s.startswith('HICHANX_ERROR:'):
     msg=s[len('HICHANX_ERROR:'):][:900]
     if self.auth_chat:await self.app.bot.send_message(self.auth_chat,'❌ ورود ناموفق:\n'+msg,reply_markup=self.menu())
     # Keep cooldown on failures that are rate-related; clear it for ordinary errors.
     if self.auth_phone and not any(x in msg for x in ('محدود','زیاد','Flood','درخواست')):
      self.db.clear_auth_last_request(self.auth_phone)
     self.states.pop(self._owner_id(),None)
  finally:
   try:await p.wait()
   except Exception:pass
   self.proc=None;self.auth_phone=None;self.auth_kind=None;self.auth_prompt_event=None

 def _owner_id(self):
  return int(OWNER_TELEGRAM_ID)

 async def auth_input(self,x):
  if not self.proc or self.proc.returncode is not None:
   await self.app.bot.send_message(self.auth_chat,'❌ فرآیند ورود تمام شده؛ کد جدیدی درخواست نمی‌شود.');return
  try:
   self.proc.stdin.write((x.strip()+'\n').encode());await self.proc.stdin.drain()
  except Exception as e:
   await self.app.bot.send_message(self.auth_chat,'❌ ارسال کد به فرآیند ورود ناموفق بود: '+str(e)[:300])

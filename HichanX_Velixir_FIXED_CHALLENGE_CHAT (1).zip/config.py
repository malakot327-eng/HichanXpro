import os
from dotenv import load_dotenv

# Load .env when present. Velixir environment variables take precedence.
load_dotenv()

BOT_NAME = os.getenv('BOT_NAME', 'HichanX').strip() or 'HichanX'
# Accept both HichanX's explicit name and the simple BOT_TOKEN name used by
# the previously working Velixir project.
TELEGRAM_BOT_TOKEN = (
    os.getenv('TELEGRAM_BOT_TOKEN') or os.getenv('BOT_TOKEN') or ''
).strip()

_owner_raw = os.getenv('OWNER_TELEGRAM_ID', '8883059306').strip()
if not _owner_raw:
    # Optional compatibility with ADMIN_IDS=123,456 from the working project.
    _owner_raw = (os.getenv('ADMIN_IDS', '').split(',')[0] or '0').strip()
try:
    OWNER_TELEGRAM_ID = int(_owner_raw)
except ValueError:
    OWNER_TELEGRAM_ID = 0

SPLUS_SESSION = os.getenv('SPLUS_SESSION', 'data/hichanx_session').strip() or 'data/hichanx_session'
DB_PATH = os.getenv('DB_PATH', 'data/hichanx.db').strip() or 'data/hichanx.db'
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO').strip().upper() or 'INFO'

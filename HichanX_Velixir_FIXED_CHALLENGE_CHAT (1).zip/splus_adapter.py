import inspect, logging
log=logging.getLogger('HichanX.splus')
class SplusAdapter:
    def __init__(self,client): self.client=client
    async def call(self,names,*args,**kwargs):
        last=None
        for n in names:
            fn=getattr(self.client,n,None)
            if not callable(fn): continue
            try:
                r=fn(*args,**kwargs); return await r if inspect.isawaitable(r) else r
            except (TypeError,AttributeError) as e: last=e
        raise NotImplementedError('No compatible SplusPy method: '+','.join(names)) from last
    async def me(self): return await self.call(['get_me','me'])
    async def chats(self): return await self.call(['get_chats','get_dialogs','chats'])
    async def leave_chat(self,cid): return await self.call(['leave_chat','leave_group','leave'],cid)
    async def send_message(self,cid,text): return await self.call(['send_message'],cid,text)
    async def delete(self,cid,msg):
        mid=getattr(msg,'id',getattr(msg,'message_id',msg))
        for args in ((cid,[mid]),(cid,mid),(mid,)):
            try:return await self.call(['delete_messages','delete_message','delete'],*args)
            except (NotImplementedError,TypeError):pass
        raise NotImplementedError('delete message API unavailable')
    async def purge(self,cid,limit=50):
        try:return await self.call(['purge_messages'],cid,limit=limit)
        except NotImplementedError:
            # Fallback: retrieve recent messages and delete individually.
            msgs=await self.call(['get_messages'],cid,limit=limit)
            count=0
            for m in msgs or []:
                try: await self.delete(cid,m); count+=1
                except Exception: pass
            return count
    async def ban(self,cid,uid): return await self.call(['ban_user','ban_member','ban'],cid,uid)
    async def unban(self,cid,uid): return await self.call(['unban_user','unban_member','unban'],cid,uid)
    async def kick(self,cid,uid):
        try:return await self.call(['kick_user','kick_member','kick'],cid,uid)
        except NotImplementedError:return await self.ban(cid,uid)
    async def mute(self,cid,uid,duration=None):
        if duration is not None:
            try:return await self.call(['mute_user','mute_member','mute'],cid,uid,duration)
            except (NotImplementedError,TypeError):pass
        return await self.call(['mute_user','mute_member','mute'],cid,uid)
    async def unmute(self,cid,uid): return await self.call(['unmute_user','unmute_member','unmute'],cid,uid)
    async def participants(self,cid): return await self.call(['get_participants','get_chat_members','participants'],cid)
    async def permissions(self,cid,uid): return await self.call(['get_permissions','get_user_permissions'],cid,uid)
    async def pin(self,cid,msg): return await self.call(['pin_message','pin_chat_message'],cid,msg)
    async def unpin(self,cid): return await self.call(['unpin_all','unpin_all_messages'],cid)

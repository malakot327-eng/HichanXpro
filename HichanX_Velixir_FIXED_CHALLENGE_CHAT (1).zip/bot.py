import asyncio,logging
from config import BOT_NAME,TELEGRAM_BOT_TOKEN,OWNER_TELEGRAM_ID,DB_PATH
from database import Database
from hichanx_core import HichanXCore
from telegram_panel import TelegramPanel
from scheduler import mute_scheduler
logging.basicConfig(level=logging.INFO,format='%(asctime)s | %(levelname)s | %(name)s | %(message)s',force=True)
log=logging.getLogger(BOT_NAME)
async def run():
 if not TELEGRAM_BOT_TOKEN:raise RuntimeError('TELEGRAM_BOT_TOKEN/BOT_TOKEN is missing')
 if not OWNER_TELEGRAM_ID:raise RuntimeError('OWNER_TELEGRAM_ID is missing')
 db=Database(DB_PATH);core=HichanXCore(db);panel=TelegramPanel(core,db);await panel.start();log.info('%s started; owner=%s',BOT_NAME,OWNER_TELEGRAM_ID)
 cleaner=None
 try:
  while True:
   if core.adapter: 
    if cleaner is None or cleaner.done(): cleaner=asyncio.create_task(mute_scheduler(db,core.adapter))
   await asyncio.sleep(5)
 except asyncio.CancelledError:pass
 finally:
  if cleaner:cleaner.cancel()
  await core.stop();await panel.stop()
if __name__=='__main__':asyncio.run(run())
